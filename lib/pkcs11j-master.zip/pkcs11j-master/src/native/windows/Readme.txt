The PKCS11wrapper.dsw is a Visual C++ 6.0 workspace file.
The PKCS11wrapper.sln is a visual C++ 2008 solution file.