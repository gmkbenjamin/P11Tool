This port to Mac OS X is based on the code of the Linux port. Actually, there
are no differences in the source code. Only the Makefile is different.

The makefile creates a universal version, which can be used for ppc, ppc64, 1386 and x86_64. 
